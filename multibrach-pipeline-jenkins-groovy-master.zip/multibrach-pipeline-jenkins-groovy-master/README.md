# multibrachpipeline-jenkins-groovy
multibrachpipeline-jenkins-groovy
# Docker folder
```
Contains file for building docker image for kubernets context and helm repo https://github.com/eldhodevops/multibrachpipeline-jenkins-groovy/blob/master/deployUsingYamlConfig.groovy#L41

https://github.com/eldhodevops/multibrach-pipeline-jenkins-groovy/blob/master/masterchartdeploy.groovy#L40
```
